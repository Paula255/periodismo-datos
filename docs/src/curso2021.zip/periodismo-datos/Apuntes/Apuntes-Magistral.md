# 14 septiembre 2021

## Las URL

Partes de la URL

- Protocolo
- Dominio
- Estructura de carpetas

La web es un servicio de internet. Cada servicio se inicia con un protocolo (https.; ssh;ftp...). Se separa del dominio con ://.

Los dominios de primer nivel (TLD) son .com, .es, .gob, .edu... Un ejemplo sería uc3m.es o github.com. Se separa de la estructura de carpetas con /.

El archivo básico en una página web es un Index.html

## Buscar datasets

Awesome+términos en Github para encontrar recopilaciones

Kaggel

Colaboratory de Google con notebooks
