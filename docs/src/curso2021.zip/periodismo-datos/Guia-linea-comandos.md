Guía rápida de la línea de comandos
ls -l: da información completa sobre los archivos (permisos, propiedad, fecha de modificación y tamaño)
pwd: dónde estás
env: muestra todas las variables
mkdir: crea una carpeta
cd: cambiar de directorio
cd ..: retroceder un directorio
tail: muestra las últimas líneas
head: muestra las primeras líneas
